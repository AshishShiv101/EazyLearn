import SwiftUI

struct TagView: View {
    let tags: [(name: String, icon: String, color: Color)] = [
        ("Exam", "book.closed.fill", .red),
        ("Notes", "note.text", .blue),
        ("Routine", "calendar", .green),
        ("Finance", "dollarsign.circle.fill", .orange)
    ]

    @State private var selectedTag: String? = nil
    @ObservedObject private var noteDataManager = NoteDataManager.shared

    var body: some View {
        VStack(spacing: 15) {
            HStack(spacing: 15) {
                TagButton(title: tags[0].name, icon: tags[0].icon, color: tags[0].color, action: { selectedTag = tags[0].name })
                TagButton(title: tags[1].name, icon: tags[1].icon, color: tags[1].color, action: { selectedTag = tags[1].name })
            }
            HStack(spacing: 15) {
                TagButton(title: tags[2].name, icon: tags[2].icon, color: tags[2].color, action: { selectedTag = tags[2].name })
                TagButton(title: tags[3].name, icon: tags[3].icon, color: tags[3].color, action: { selectedTag = tags[3].name })
            }
        }
        .padding()
        .sheet(item: $selectedTag) { tag in
            BottomSheetView(tag: tag, notes: noteDataManager.notes.filter { $0.tag == tag })
                .background(BackgroundBlurView().ignoresSafeArea()) // Full-screen blur
        }
    }
}

// MARK: - Tag Button View
struct TagButton: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void
    @State private var isPressed = false

    var body: some View {
        VStack {
            Image(systemName: icon)
                .font(.system(size: 28))
                .foregroundColor(.white)

            Text(title)
                .font(.headline)
                .foregroundColor(.white)
        }
        .padding()
        .frame(width: 120, height: 120)
        .background(color)
        .cornerRadius(20)
        .shadow(color: color.opacity(0.4), radius: 5, x: 0, y: 4)
        .scaleEffect(isPressed ? 0.9 : 1.0)
        .animation(.spring(), value: isPressed)
        .onTapGesture {
            isPressed.toggle()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                isPressed.toggle()
                action()
            }
        }
    }
}

struct BottomSheetView: View {
    let tag: String
    let notes: [NoteModel]
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .center, spacing: 20) {
            Text(tag)
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
                .frame(maxWidth: .infinity, alignment: .center) // Center align title
                .padding(.top, 15) // Added top margin

            ScrollView {
                VStack(spacing: 15) {
                    ForEach(notes) { note in
                        NoteCard2(note: note)
                    }
                }
                .padding(.horizontal)
            }
            .padding(.bottom, 10) // Ensure content isn't cut off
        }
        .frame(maxWidth: .infinity)
        .background(Color(.systemBackground))
        .cornerRadius(20)
        .shadow(radius: 10)
        .ignoresSafeArea(edges: .bottom) // Fixes bottom gap
        .presentationDetents([.fraction(0.4), .large]) // Start at 40% height, then expand
        .presentationDragIndicator(.visible)
    }
}

// MARK: - Background Blur View
struct BackgroundBlurView: UIViewRepresentable {
    func makeUIView(context: Context) -> UIVisualEffectView {
        let view = UIVisualEffectView(effect: UIBlurEffect(style: .systemThinMaterial))
        view.frame = UIScreen.main.bounds // Ensure full-screen coverage
        return view
    }

    func updateUIView(_ uiView: UIVisualEffectView, context: Context) {}
}

// MARK: - Note Card View
struct NoteCard2: View {
    let note: NoteModel

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // Tag marker at the top-right corner
            HStack {
                Spacer()
                Text(note.tag)
                    .font(.caption)
                    .bold()
                    .foregroundColor(.white)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color(hex: note.tagColor))
                    .cornerRadius(10)
                    .padding(.top, 5)
                    .padding(.trailing, 5)
            }

            Text(note.text)
                .font(.headline)
                .foregroundColor(.primary)
                .lineLimit(2)

            if let imageData = note.imageData, let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 60)
                    .cornerRadius(8)
            }

            Spacer() // Push content to the top

            Text(formattedDate(note.timestamp))
                .font(.caption)
                .foregroundColor(.gray)
        }
        .padding()
        .frame(height: 140)
        .background(Color(.secondarySystemBackground))
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }

    private func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d, h:mm a" // Example: "Jan 23, 3:45 PM"
        return formatter.string(from: date)
    }
}

// MARK: - Extensions
extension String: Identifiable {
    public var id: String { self }
}

#Preview {
    TagView()
}
