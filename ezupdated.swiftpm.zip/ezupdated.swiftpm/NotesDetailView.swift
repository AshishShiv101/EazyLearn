import SwiftUI

struct NotesDetailView: View {
    let note: NoteModel
    var onDelete: () -> Void // Closure to handle delete action
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text(note.text)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                    .padding(.top, 20)
                    .multilineTextAlignment(.center)

                if let imageData = note.imageData, let uiImage = UIImage(data: imageData) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: 300)
                        .cornerRadius(12)
                        .padding()
                }

                Text("Tag: \(note.tag)")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color(hex: note.tagColor) ?? .gray)
                    .cornerRadius(8)

                Spacer()

                Text("Created on \(formattedDate(from: note.timestamp))") // Use the timestamp directly
                    .font(.caption)
                    .foregroundColor(.gray)
                    .padding(.bottom, 20)
            }
            .padding()
            .navigationTitle("Note Detail")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                // Add a delete button to the top-right corner
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        onDelete() // Trigger the delete action
                    }) {
                        Image(systemName: "trash") // Use a trash icon
                            .foregroundColor(.red) // Make the icon red
                    }
                }
            }
        }
    }

    private func formattedDate(from date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}
