import Foundation
import SwiftUI

class NoteDataManager: ObservableObject {
    @MainActor static let shared = NoteDataManager() // Singleton for global access
    
    @Published var notes: [NoteModel] = []

    let fileName = "saved_notes.json"

    init() {
        loadNotes()
    }

    private func getFileURL() -> URL {
        let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return documentDirectory.appendingPathComponent(fileName)
    }

    func saveNotes() {
        do {
            let data = try JSONEncoder().encode(notes)
            try data.write(to: getFileURL(), options: .atomic)
        } catch {
            print("Error saving notes: \(error)")
        }
    }

    func loadNotes() {
        let url = getFileURL()
        guard FileManager.default.fileExists(atPath: url.path) else { return }

        do {
            let data = try Data(contentsOf: url)
            notes = try JSONDecoder().decode([NoteModel].self, from: data)
        } catch {
            print("Error loading notes: \(error)")
        }
    }

    func addNote(_ note: NoteModel) {
        notes.append(note)
        saveNotes()
    }

    func deleteNote(_ note: NoteModel) {
        notes.removeAll { $0.id == note.id }
        saveNotes()
    }
}
