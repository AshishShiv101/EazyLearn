import SwiftUI

struct RecentView: View {
    @StateObject private var noteDataManager = NoteDataManager.shared

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            // Section heading
            Text("Recent")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.primary)
                .padding(.horizontal)
                .padding(.top)

            // Check if there are no notes
            if noteDataManager.notes.isEmpty {
                Text("No notes available. Create a new note to get started!")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .center)
            } else {
                // Horizontal carousel of recent notes
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 15) {
                        // Sort notes by timestamp in descending order (most recent first)
                        ForEach(noteDataManager.notes.sorted(by: { $0.timestamp > $1.timestamp })) { note in
                            NoteCard(note: note)
                                .frame(width: 250, height: 140) // Adjust height to ensure visibility
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom) // Extra padding to prevent clipping
                }
            }
        }
        .padding(.bottom)
        .onAppear {
            noteDataManager.loadNotes()
        }
    }
}

struct NoteCard: View {
    let note: NoteModel

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // Tag marker at the top-right corner
            HStack {
                Spacer()
                Text(note.tag)
                    .font(.caption)
                    .bold()
                    .foregroundColor(.white)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color(hex: note.tagColor))
                    .cornerRadius(10)
                    .padding(.top, -5)
                    .padding(.trailing, -5)
            }

            Text(note.text)
                .font(.headline)
                .foregroundColor(.primary)
                .lineLimit(2)

            if let imageData = note.imageData, let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 60)
                    .cornerRadius(8)
            }

            Spacer() // Push content to the top

            // Display the formatted timestamp
            Text(formatDate(note.timestamp))
                .font(.caption)
                .foregroundColor(.gray)
        }
        .padding()
        .frame(height: 140) // Set a fixed height to prevent clipping
        .background(Color(.systemBackground))
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }

    // Helper function to format the date
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

// MARK: - Color Extension for Hex Support
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(.sRGB, red: Double(r) / 255, green: Double(g) / 255, blue: Double(b) / 255, opacity: Double(a) / 255)
    }
}

#Preview {
    RecentView()
}
