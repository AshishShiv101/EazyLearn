import SwiftUI

struct NoteView: View {
    @State private var noteText: String = UserDefaults.standard.string(forKey: "savedNote") ?? ""
    @State private var showPromptAlert: Bool = false
    @State private var promptText: String = ""
    @State private var isSubmitted: Bool = false
    @State private var opacity: Double = 1.0
    @State private var cardHeight: CGFloat = 300
    @State private var selectedTag: (name: String, color: Color) = (UserDefaults.standard.string(forKey: "savedTag") ?? "Select Tag", Color.gray)

    @ObservedObject private var noteDataManager = NoteDataManager.shared

    let tags: [(name: String, icon: String, color: Color)] = [
        ("Exam", "book.closed.fill", .red),
        ("Notes", "note.text", .blue),
        ("Routine", "calendar", .green),
        ("Finance", "dollarsign.circle.fill", .orange)
    ]

    var body: some View {
        NavigationView {
            ZStack {
                VStack(spacing: 20) {
                    VStack(alignment: .leading) {
                        HStack {
                            Text("Your Notes")
                                .font(.headline)
                                .foregroundColor(.primary)

                            Spacer()

                            Menu {
                                ForEach(tags, id: \.name) { tag in
                                    Button(action: {
                                        selectedTag = (tag.name, tag.color)
                                        UserDefaults.standard.set(tag.name, forKey: "savedTag")
                                    }) {
                                        Label(tag.name, systemImage: tag.icon)
                                            .foregroundColor(tag.color)
                                    }
                                }
                            } label: {
                                HStack {
                                    Image(systemName: "tag.fill")
                                        .foregroundColor(selectedTag.color)
                                    Text(selectedTag.name)
                                        .font(.subheadline)
                                        .foregroundColor(selectedTag.color)
                                }
                                .padding(8)
                                .background(Color(.secondarySystemBackground))
                                .cornerRadius(10)
                            }
                        }

                        ZStack(alignment: .topTrailing) {
                            if !isSubmitted {
                                TextEditor(text: $noteText)
                                    .padding()
                                    .frame(height: isSubmitted ? 0 : 150)
                                    .background(Color(.secondarySystemBackground))
                                    .cornerRadius(15)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 15)
                                            .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                                    )
                                    .opacity(opacity)
                                    .animation(.easeInOut(duration: 0.5), value: isSubmitted)
                                    .onChange(of: noteText) { newValue in
                                        UserDefaults.standard.set(newValue, forKey: "savedNote")
                                    }
                            }
                        }
                    }
                    .padding()

                    Button(action: saveNote) {
                        Text("Save")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.yellow)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                    }
                    .padding(.top, 15)
                }
                .background(Color(.systemBackground))
                .cornerRadius(20)
                .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
                .padding(.horizontal)
                .frame(height: cardHeight)
            }
            .navigationTitle("My Notes")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func saveNote() {
        let newNote = NoteModel(
            text: noteText,
            tag: selectedTag.name,
            tagColor: selectedTag.color.toHex() ?? "#000000",
            timestamp: Date() // Set the current date and time
        )
        
        noteDataManager.addNote(newNote)

        withAnimation {
            isSubmitted = true
            opacity = 0
            cardHeight = 0
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            withAnimation {
                noteText = ""
                selectedTag = ("Select Tag", .gray)
                cardHeight = 300
                isSubmitted = false
                opacity = 1
            }
        }
    }
}

extension Color {
    func toHex() -> String? {
        guard let components = UIColor(self).cgColor.components else { return nil }
        let r = Float(components[0])
        let g = Float(components[1])
        let b = Float(components[2])
        return String(format: "#%02lX%02lX%02lX", lroundf(r * 255), lroundf(g * 255), lroundf(b * 255))
    }
}

#Preview {
    NoteView()
}
