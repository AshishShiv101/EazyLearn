import Foundation
import SwiftUI

struct NoteModel: Identifiable, Codable {
    var id: UUID = UUID()
    var text: String
    var imageData: Data? // Save image as Data
    var tag: String
    var tagColor: String // Save color as a hex string
    var timestamp: Date = Date() // Add a timestamp for when the note is created
}
