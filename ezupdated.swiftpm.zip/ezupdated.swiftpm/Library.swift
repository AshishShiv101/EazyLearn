import SwiftUI

struct Notes: View {
    @ObservedObject var noteManager = NoteDataManager.shared
    @State private var searchText = ""
    @State private var selectedTag: String? = nil
    
    let tags: [(name: String, color: Color)] = [
        ("Exam", .red),
        ("Notes", .blue),
        ("Routine", .green),
        ("Finance", .orange)
    ]
    
    var filteredNotes: [NoteModel] {
        let searchFiltered = searchText.isEmpty ? noteManager.notes : noteManager.notes.filter {
            $0.text.localizedCaseInsensitiveContains(searchText)
        }
        
        if let selectedTag = selectedTag {
            return searchFiltered.filter { $0.tag == selectedTag }
        } else {
            return searchFiltered
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.yellow)
                    TextField("Search notes", text: $searchText)
                        .padding(8)
                        .background(Color.yellow.opacity(0.1))
                        .cornerRadius(8)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        // Add a spacer to push the buttons to the center
                        Spacer()
                        
                        ForEach(tags, id: \.name) { tag in
                            Button(action: {
                                selectedTag = selectedTag == tag.name ? nil : tag.name
                            }) {
                                Text(tag.name)
                                    .font(.subheadline)
                                    .foregroundColor(.white)
                                    .padding(.vertical, 10)
                                    .padding(.horizontal, 16)
                                    .background(tag.color.opacity(selectedTag == tag.name ? 1.0 : 0.6))
                                    .cornerRadius(20)
                            }
                        }
                        
                        // Add another spacer to balance the centering
                        Spacer()
                    }
                    .frame(maxWidth: .infinity) // Ensure the HStack takes full width
                }
                .padding(.horizontal) // Add horizontal padding to the ScrollView
                
                ScrollView {
                    if filteredNotes.isEmpty {
                        Text("No notes available.")
                            .font(.headline)
                            .foregroundColor(.gray)
                            .padding()
                    } else {
                        LazyVGrid(columns: [GridItem(.flexible(), spacing: 16)], spacing: 16) {
                            ForEach(filteredNotes) { note in
                                NavigationLink(destination: NotesDetailView(note: note, onDelete: {
                                    noteManager.deleteNote(note)
                                })) {
                                    NoteCardView(note: note)
                                        .contextMenu {
                                            Button(role: .destructive) {
                                                // Delete the note
                                                noteManager.deleteNote(note)
                                            } label: {
                                                Label("Delete", systemImage: "trash")
                                            }
                                        }
                                }
                            }
                        }
                        .padding(.horizontal, 16)
                    }
                }
            }
            .background(Color(.systemGroupedBackground).edgesIgnoringSafeArea(.all))
            .navigationBarTitle("My Notes", displayMode: .inline)
        }
    }
}

struct NoteCardView: View {
    let note: NoteModel
    
    var formattedDate: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: note.id.uuidString.toDate())
    }
    
    var tagColor: Color {
        Color(hex: note.tagColor) ?? .gray
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(note.text)
                    .font(.title3)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                    .lineLimit(1)
                
                Spacer()
                
                Text(note.tag)
                    .font(.caption)
                    .foregroundColor(.white)
                    .padding(6)
                    .background(tagColor)
                    .cornerRadius(8)
            }
            
            Text(formattedDate)
                .font(.caption)
                .foregroundColor(.gray)
                .padding(.top, 8)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.1), radius: 8, x: 0, y: 4)
    }
}

extension String {
    func toDate() -> Date {
        let formatter = ISO8601DateFormatter()
        return formatter.date(from: self) ?? Date()
    }
}

// Preview
#Preview {
    Notes()
}
